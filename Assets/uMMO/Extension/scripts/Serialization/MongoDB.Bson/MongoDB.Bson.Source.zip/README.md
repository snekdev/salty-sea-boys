# MongoDB.Bson4Unity
MongoDB Bson v1.11.0 (serialization engine) made ready for Unity with api compatibility level .Net 2.0 Subset. Tested with Unity 5.

Used in uMMO 2.0 (https://www.assetstore.unity3d.com/en/#!/content/13867)
