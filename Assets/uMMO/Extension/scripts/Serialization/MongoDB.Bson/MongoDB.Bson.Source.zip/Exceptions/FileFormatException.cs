﻿/*
 * Created by SoftRare as a bridge for using MongoDB Bson with Unity.
 */

using System;


class FileFormatException : Exception{

    // constructors
    /// <summary>
    /// Initializes a new instance of the FileFormatException class.
    /// </summary>
    public FileFormatException()
        : base()
    {
    }

    /// <summary>
    /// Initializes a new instance of the FileFormatException class.
    /// </summary>
    /// <param name="message">The error message.</param>
    public FileFormatException(string message)
        : base(message)
    {
    }

    /// <summary>
    /// Initializes a new instance of the FileFormatException class.
    /// </summary>
    /// <param name="message">The error message.</param>
    /// <param name="innerException">The inner exception.</param>
    public FileFormatException(string message, Exception innerException)
            : base(message, innerException)
        {
    }
}
